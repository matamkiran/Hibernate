package service;

import java.util.List;

import com.hibernate.tutorial.Product;

public interface IProductListService {
	
	List<Product> fetchProductService();
	
	

}
