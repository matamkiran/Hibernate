package service.implementation;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hibernate.persistence.HibernatePersistence;
import com.hibernate.tutorial.Product;

import dao.IProductListDAO;
import dao.implementation.ProductListDAO;
import service.IProductListService;

public class ProductListService implements IProductListService {

	
	private IProductListDAO iProductListDAO= new ProductListDAO();
	
	 Transaction transaction = null;
	Session	prepareSession() {
	//try {
	Session session = HibernatePersistence.getSessionFactory().openSession();

	  transaction =  session.beginTransaction();
    
   // return session;
	/*}catch(Exception e) {
		e.getLocalizedMessage();
		
	}finally {
		transaction.commit();
	}*/
	return session;
	
	}
	Session session = prepareSession();
	public List<Product> fetchProductService() {
		
		
	return	iProductListDAO.fetchProductListDAO(session);
		
	}
	

}
