package service.implementation;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hibernate.persistence.HibernatePersistence;

import bean.helper.ProductHelper;
import dao.IProductIngredientsDAO;
import dao.implementation.ProductIngredientsDetailsDAO;
import service.IProductIngredientsService;

public class ProductIngredientDetailsService implements IProductIngredientsService {
	
	
	private IProductIngredientsDAO iIProductIngredientsDAO = new ProductIngredientsDetailsDAO();
	
	 Transaction transaction = null;
		Session	prepareSession() {
		try {
		Session session = HibernatePersistence.getSessionFactory().openSession();

		  transaction =  session.beginTransaction();
	    
	    return session;
		}catch(Exception e) {
			e.getLocalizedMessage();
			
		}finally {
			transaction.commit();
		}
		return session;
		
		}
		Session session = prepareSession();
		
		public List<ProductHelper> fetchProductIngredints() {

		return	iIProductIngredientsDAO.fetchProductIngredintsDAO(session);
		}
		
		
		
}
