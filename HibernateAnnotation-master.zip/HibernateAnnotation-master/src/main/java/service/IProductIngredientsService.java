package service;

import java.util.List;

import org.hibernate.Session;

import bean.helper.ProductHelper;

public interface IProductIngredientsService {

	public List<ProductHelper> fetchProductIngredints();
	
	
	

}
