import java.util.List;

import com.hibernate.persistence.HibernatePersistence;
import com.hibernate.tutorial.Product;

import bean.ProductIngredients;
import bean.helper.ProductHelper;
import service.IProductIngredientsService;
import service.IProductListService;
import service.implementation.ProductIngredientDetailsService;
import service.implementation.ProductListService;


public class Main {

    public static void main( String[] args )
    {
    	/**Session session = HibernatePersistence.getSessionFactory().openSession();

        session.beginTransaction();

    //Make some product for storing in database
       // product.setId(4);
        product.setName("COKE");
        product.setCode("C001");
        product.setPrice(new BigDecimal("18.00"));

        //Save product to database
        Integer productId =(Integer) session.save(product);
        session.getTransaction().commit();
        **/
    	IProductListService iProductListService= new ProductListService();
    	
    	IProductIngredientsService iProductIngredientsService=new ProductIngredientDetailsService();
    	
    	List<Product> productList=iProductListService.fetchProductService();
    	
    	
    	System.out.println(productList.size());
    	
    	for(Product obj:productList) {
    		System.out.print(obj.getId() + " ");
    		System.out.print(obj.getName() + " ");
    		System.out.println(obj.getPrice());
    		for(ProductIngredients pi: obj.getIngredientsList()) {
    			System.out.println("your ingredients in " + obj.getName()  + "are : "+pi.getIngName()  + pi.getIngPercentage());
    		}
    		
    	}
    	
    	List<ProductHelper>	ph=iProductIngredientsService.fetchProductIngredints();
    	
    	
    	for(ProductHelper pho:ph) {
    		System.out.println(pho.getId() +" " + pho.getIngName() + " " + pho.getProductName());
    	}
        
        //close session
        HibernatePersistence.shutdown();
}
}