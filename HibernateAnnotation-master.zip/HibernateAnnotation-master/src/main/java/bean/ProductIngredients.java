/**
 * 
 */
package bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author Divya
 * insert into product_ingredients(ing_name,product_id,ing_percentage) values('VitaminA',2,50)
 *
 */

@Entity
@Table(name="product_ingredients")
public class ProductIngredients {
	
	 @Id
	 @GenericGenerator(name="generator", strategy="increment")
	 @GeneratedValue(generator="generator")
	 @Column(name = "id", unique = true, nullable = false)
	private Integer id;
	 
	 @Column(name = "ing_name",nullable = false)
	 private String ingName;
	 
	 
	 @Column(name="product_id")
	 private Integer productId;
	 
	 
	 
	 @Column(name="ing_percentage",nullable=false)
	 private Integer ingPercentage;
	 
	 

	/**
	 * @return the productId
	 */
	public Integer getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the ingName
	 */
	public String getIngName() {
		return ingName;
	}

	/**
	 * @param ingName the ingName to set
	 */
	public void setIngName(String ingName) {
		this.ingName = ingName;
	}

	/**
	 * @return the ingPercentage
	 */
	public Integer getIngPercentage() {
		return ingPercentage;
	}

	/**
	 * @param ingPercentage the ingPercentage to set
	 */
	public void setIngPercentage(Integer ingPercentage) {
		this.ingPercentage = ingPercentage;
	}
	 

	 
}
