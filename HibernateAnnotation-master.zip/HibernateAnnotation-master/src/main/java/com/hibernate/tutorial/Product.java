package com.hibernate.tutorial;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.GenericGenerator;

import bean.ProductIngredients;


/**
 * Model class for Product
 */
@Entity
@Table(name = "product")
public class Product implements Serializable {

    /**
	 * Product Class using Annotation
	 */
	private static final long serialVersionUID = 1L;
	 @Id
	 @GenericGenerator(name="generator", strategy="increment")
	 @GeneratedValue(generator="generator")
	 @Column(name = "id", unique = true, nullable = false)
	private Integer id;
    private String code;
    private String name;
    private BigDecimal price;
    
    
    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    //@JoinColumn(referencedColumnName ="id" )
    @JoinColumn(name = "product_id", referencedColumnName = "id")
    
    private List<ProductIngredients> ingredientsList;
    
    
    
   
	/**
	 * @return the ingredientsList
	 */
	public List<ProductIngredients> getIngredientsList() {
		return ingredientsList;
	}
	/**
	 * @param ingredientsList the ingredientsList to set
	 */
	public void setIngredientsList(List<ProductIngredients> ingredientsList) {
		this.ingredientsList = ingredientsList;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	@Column(name = "code", unique = true, nullable = false, length = 10)
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	
	@Column(name = "name", unique = true, nullable = false, length = 10)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Column(name = "price", unique = true, nullable = false, length = 10)
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	
	@Override
    public String toString() {
        return "Product [id=" + id + ", code=" + code + ", name="
                + name + ", price=" + price + "]";
    } 
    
}