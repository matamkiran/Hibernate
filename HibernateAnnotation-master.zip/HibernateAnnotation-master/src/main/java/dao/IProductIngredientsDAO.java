package dao;

import java.util.List;

import org.hibernate.Session;

import bean.helper.ProductHelper;

public interface IProductIngredientsDAO {

	List<ProductHelper> fetchProductIngredintsDAO(Session session);

}
