package dao.implementation;

import java.util.List;

import org.hibernate.Session;

import com.hibernate.tutorial.Product;

import dao.IProductListDAO;



public class ProductListDAO implements IProductListDAO{

	public List<Product> fetchProductListDAO(Session session) {
	
		return session.createQuery("FROM Product").list();
	}

}
