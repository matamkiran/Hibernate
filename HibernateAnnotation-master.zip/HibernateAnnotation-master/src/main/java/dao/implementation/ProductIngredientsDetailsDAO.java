package dao.implementation;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.transform.Transformers;

import bean.helper.ProductHelper;
import dao.IProductIngredientsDAO;

public class ProductIngredientsDetailsDAO implements IProductIngredientsDAO {

	
	public List<ProductHelper> fetchProductIngredintsDAO(Session session) {

	List<ProductHelper> phlist=session.createSQLQuery("select p.id as \"id\",p.name as \"productName\",pi.ing_name as \"ingName\" from public.product p ,"
				+ "public.product_ingredients pi where p.id=pi.product_id ")
		.setResultTransformer(Transformers.aliasToBean(ProductHelper.class)).list();
		
	return phlist;
	
	}

	
	
}
