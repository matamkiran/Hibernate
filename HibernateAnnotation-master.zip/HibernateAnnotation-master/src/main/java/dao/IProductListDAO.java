package dao;

import java.util.List;

import org.hibernate.Session;

import com.hibernate.tutorial.Product;

public interface IProductListDAO {
	
	List<Product>  fetchProductListDAO(Session session);

}
